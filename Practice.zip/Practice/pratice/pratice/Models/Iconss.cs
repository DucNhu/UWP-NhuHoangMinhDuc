﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pratice.Models
{
    public class IconSS
    {
        public string iconPath { get; set; }
    }
}
