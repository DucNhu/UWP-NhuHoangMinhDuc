﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pratice.Models
{
    public class Icon
    {
        public string IconPath { get; set; }
    }
}
