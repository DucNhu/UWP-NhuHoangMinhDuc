﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace product.Models
{
    public class color
    {
        public string colors { get; set; }
    }
}
